import  UsersTableView from './UsersTableView';

function UserPage() {
    return (
        <UsersTableView></UsersTableView>
    );
}

export default UserPage;
