export const LogMessage: any = (message: string) => {
    console.log(message);
};
